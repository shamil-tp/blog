async function add(id,username,password) {
    await Bloger.create({id,username,password})
}
console.log('started')
add(Date.now(),'sha','123')

//
try{

}catch(e){
    console.log('there is an error:')
    console.log(e)
}