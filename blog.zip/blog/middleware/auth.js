

exports.isLoggedIn =(req,res,next)=>{

    try{
        let user = req.cookies?.uc?.username
        if(!user){
            return res.redirect('/login')
        }
        return next()
    }catch(e){
        console.log('there is an error:')
        console.log(e)
    }
}