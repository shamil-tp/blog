const router = require('express').Router()

const {getLoginPage,Login,getSignupPage,Signup,Logout}=require('../controllers/auth')


router
    .route('/login')
    .get(getLoginPage)
    .post(Login)

router
    .route('/signup')
    .get(getSignupPage)
    .post(Signup)

router
    .route('/logout')
    .get(Logout)

module.exports =router