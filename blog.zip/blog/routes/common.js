const router = require('express').Router()

const {Blogs}=require('../controllers/blogs')
const {Post, createPost}=require('../controllers/create')
const {Home}=require('../controllers/home')

router
    .route('/blogs')
    .get(Blogs)

router
    .route('/post')
    .get(Post)
    .post(createPost)

router
    .route('/home')
    .get(Home)

module.exports =router