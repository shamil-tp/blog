require('dotenv').config()
const cookieParser = require('cookie-parser')
const express = require('express')
const app = express()

app.set('view engine','ejs')
app.use(express.static('./static'))
app.use(express.urlencoded({extended:true}))
app.use(cookieParser())

const { isLoggedIn } = require('./middleware/auth')

const {connectDB}=require('./databse/connect')
connectDB()

// const {getLoginPage,Login,getSignupPage,Signup,Logout}=require('./controllers/auth')
// const {Blogs}=require('./controllers/blogs')
// const {Post, createPost}=require('./controllers/create')
// const {Home}=require('./controllers/home')

// app.get('/login',getLoginPage)
// app.get('/signup',getSignupPage)
// app.post('/signup',Signup)
// app.post('/login',Login)
// app.get('/blogs',isLoggedIn,Blogs)
// app.get('/post',isLoggedIn,Post)
// app.post('/post',isLoggedIn,createPost)
// app.get('/home',isLoggedIn,Home)
// app.get('/logout',Logout)
//app.get('/testt',Test)


let auth = require('./routes/auth')
let common = require('./routes/common')

app.use('/',auth)
app.use('/',isLoggedIn,common)


app.listen(8000,()=>{console.log('app started')})