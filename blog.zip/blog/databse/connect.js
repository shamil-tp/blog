const mongoose = require('mongoose')

let uri = process.env.DB

exports.connectDB=()=>{
    mongoose.connect(uri).then(()=>console.log('connected to database')).catch((e)=>console.log("DB failed",e));
}