const mongoose = require('mongoose')
const jwt = require('jsonwebtoken')
const bycrypt = require('bcryptjs')

const blog = new mongoose.Schema({
    blogID:String,
    username:String,
    id:String,
    blog:String
})

// usc.pre('save',async function(next){
//     if(!(this.isModified('password'))){
//         return next()
//     }
//     this.password= await bcrypt.hash(this.password,10)
//     return next()
// })

// //validate the password with passedon userpassword
// usc.methods.isPasswordCorrect = async function(userSendPassword){
//     return await bcrypt.compare(userSendPassword,this.password)
// }

// usc.methods.getJWT = function(){
//     return jwt.sign({name:this.name,username:this.username,id:this.id},process.env.JWT_SECRET)
// }


module.exports = mongoose.model("Blog",blog)