const mongoose = require('mongoose')
const jwt = require('jsonwebtoken')
const bycrypt = require('bcryptjs')

const bloger = new mongoose.Schema({
    id:String,
    username:String,
    password:String,
    blogs:[String]
})

// usc.pre('save',async function(next){
//     if(!(this.isModified('password'))){
//         return next()
//     }
//     this.password= await bcrypt.hash(this.password,10)
//     return next()
// })

// //validate the password with passedon userpassword
// usc.methods.isPasswordCorrect = async function(userSendPassword){
//     return await bcrypt.compare(userSendPassword,this.password)
// }

// usc.methods.getJWT = function(){
//     return jwt.sign({name:this.name,username:this.username,id:this.id},process.env.JWT_SECRET)
// }


module.exports = mongoose.model("Bloger",bloger)