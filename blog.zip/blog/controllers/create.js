const Blog = require('../models/Blog')

exports.Post=(req,res)=>{
    return res.render('create',{username:req.cookies.uc.username})
}

exports.createPost=async(req,res)=>{    
    try{
            let username =req.cookies.uc.username
            let blog=req.body.blog
            let id = req.cookies.uc.id
            let blogID =Date.now()
            await Blog.create({
                blogID,username,id,blog
            })
            return res.redirect('/home')
    }
    catch(e){
            console.log('blog not created:')
            console.log(e)
    
    }
}