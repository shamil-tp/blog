const Blog = require('../models/Blog')

exports.Home=async(req,res)=>{
    try{
        let id =req.cookies.uc.id
        let blog = await Blog.find({id:id}).sort({blogID:-1})
        return res.render('home',{blog:blog,username:req.cookies.uc.username})
    }catch(e){
        console.log('there is an error:')
        console.log(e)
    }
}