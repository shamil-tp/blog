const Bloger = require('../models/Bloger')

exports.getLoginPage=(req,res)=>{
    return res.render('login')
}
exports.getSignupPage=(req,res)=>{
    return res.render('signup')
}
exports.Login=async(req,res)=>{
    try{
        let {username,password} =req.body
        let bloger = await Bloger.findOne({username:username}).select('+password')
        if(!bloger){
            console.log('user does not exist')
            return res.send('<h1>username or password is incorrect</h1>')
        }
        let auth = bloger.password == password
        if(!auth){
            console.log('password is wrong')
            return res.send('<h1>username or password is incorrect</h1>')
        }
        return res.cookie('uc',bloger,{httpOnly:true}).redirect('/blogs')
    }catch(e){
        console.log('there is an error:')
        console.log(e)
    }
}
exports.Signup=async(req,res)=>{
    try{
        let {username,password}=req.body
        let id = Date.now()
        await Bloger.create({id,username,password})
        return res.redirect('/login')
    }catch(e){
        console.log('user not created:')
        console.log(e)

    }

}

exports.Logout=(req,res)=>{
    try{
        return res.clearCookie("uc").redirect('/login')
    }
    catch(e){
        console.log('there is an error:')
        console.log(e)
    }
}
// exports.Testt=((req,res)=>{
//     return res.sen
// })