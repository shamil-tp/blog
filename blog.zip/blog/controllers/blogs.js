const Blog = require('../models/Blog')

exports.Blogs=async(req,res)=>{
    try{
        let blog = await Blog.find().sort({blogID:-1})
        return res.render('blogs',{blog:blog,username:req.cookies.uc.username})
    }catch(e){
        console.log('there is an error:')
        console.log(e)
    }
}